﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Thamarat.Web.Migrations
{
    /// <inheritdoc />
    public partial class editadvance : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "CashAccountId",
                table: "WorkerAdvances",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_WorkerAdvances_CashAccountId",
                table: "WorkerAdvances",
                column: "CashAccountId");

            migrationBuilder.AddForeignKey(
                name: "FK_WorkerAdvances_CashAccounts_CashAccountId",
                table: "WorkerAdvances",
                column: "CashAccountId",
                principalTable: "CashAccounts",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_WorkerAdvances_CashAccounts_CashAccountId",
                table: "WorkerAdvances");

            migrationBuilder.DropIndex(
                name: "IX_WorkerAdvances_CashAccountId",
                table: "WorkerAdvances");

            migrationBuilder.DropColumn(
                name: "CashAccountId",
                table: "WorkerAdvances");
        }
    }
}
