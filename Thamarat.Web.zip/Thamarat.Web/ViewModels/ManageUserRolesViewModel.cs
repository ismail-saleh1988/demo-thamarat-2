﻿namespace Thamarat.Web.ViewModels
{
    public class ManageUserRolesViewModel
    {
        public string RoleName { get; set; }
        public bool IsSelected { get; set; }
    }
}
