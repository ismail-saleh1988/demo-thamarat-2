﻿namespace Thamarat.Domain
{
    public class Class1
    {

    }
}
