﻿namespace Thamarat.Infrastructure
{
    public class Class1
    {

    }
}
