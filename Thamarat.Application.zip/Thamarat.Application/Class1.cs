﻿namespace Thamarat.Application
{
    public class Class1
    {

    }
}
